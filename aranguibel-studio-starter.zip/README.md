# Paquete de arranque — Aranguibel Studio
1. Copia `content/`, `styles/`, `docs/`, `scripts/`, `public/assets/` y `CLAUDE.md` a la raíz del repo del sitio (sin borrar el código actual).
2. Responde `docs/OPEN-QUESTIONS.md` (o dile a Claude Code qué asumir).
3. Abre Claude Code en el repo y pide: "Lee CLAUDE.md y construye la primera versión completa".
Contenido: datos verificados en `content/`, 12 imágenes reales optimizadas, tokens de diseño y documentación de assets/proyectos.
