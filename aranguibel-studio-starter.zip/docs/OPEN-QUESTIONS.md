# Pendientes que solo Emmanuel puede resolver
1. **Correo oficial:** el sitio usa `aranguibelgonzaleze@gmail.com`; el Drive pertenece a `eagraphicdesigner15@gmail.com`. Elegir uno para el sitio (está en `content/site.json`).
2. **Beacons:** el enlace correcto según su perfil de Behance es `https://beacons.ai/eagraphicdesigner` (sin "l" final).
3. **Proyectos hallados en el Drive** (IAIM, UCV fútbol, La Meka, INNOVA3DLABS, Órbita): ¿son trabajos suyos? ¿cómo presentarlos? Están con `published:false`.
4. **PDF / video de ANA VALDEZ** (16 escenas): no está en el Drive. Sin él no se puede construir la experiencia 01/16–16/16.
5. **Imágenes de:** Kalhua, USB, Vintage Creation, Tu Sitio Waraira, Billy Burger's, Visualización 3D, Portfolio 2026. Solo hay material real de textil en el Drive.
6. **Años** de Ana Valdez y USB.
7. **Nombre del teleférico:** "Warairarepano" vs "Waraira".
8. **Promesas del sitio actual** ("respuesta en menos de 24 horas", "propuesta con precio"): confirmar antes de repetirlas.
9. **Formulario:** necesita un servicio real de envío (Netlify Forms, Formspree, etc.). No mostrar éxito falso.
10. **Dirección visual:** se asumió editorial oscuro + acento pixel. Confirmar o cambiar.
11. **Idiomas:** el brief nuevo es solo español; la estructura queda lista para EN.
12. **Asignaciones por lectura visual** (ver notes en cada JSON): confirmar.
