# Proyectos → servicios (solo relaciones verificadas)
| Proyecto | Fuente | Servicio(s) | Estado |
|---|---|---|---|
| Ana Valdez | Behance | Identidad de marca | confirmado; experiencia 16 escenas |
| Kalhua | Behance | Identidad de marca, Ilustración | confirmado, 2026 |
| Diseño de prendas USB | Behance | Diseño textil | confirmado |
| 2026 — Portfolio | Behance | Publicitario, Textil, 3D | confirmado (fuente de piezas) |
| IV Concurso Vintage Creation | Behance | Diseño textil | confirmado, 2026, propuesta de concurso |
| Utopía Group — Catálogo Textil 2026 | sitio actual | Diseño textil | confirmado |
| Tu Sitio Waraira | sitio actual | Diseño publicitario | confirmado |
| Billy Burger's | sitio actual | Diseño publicitario (branding vehicular) | confirmado, 2025 |
| Visualización 3D restaurante | sitio actual | Visualización 3D | confirmado, 2024 |
| IAIM, UCV fútbol, La Meka, INNOVA3DLABS, Órbita | Drive | Diseño textil (y Ilustración La Meka) | **sin confirmar** |

Servicio "Redes sociales": sin proyecto demostrado. No mostrar hasta tener evidencia.
Nexent (del primer brief) no aparece en Behance ni en el sitio: **excluido**.
